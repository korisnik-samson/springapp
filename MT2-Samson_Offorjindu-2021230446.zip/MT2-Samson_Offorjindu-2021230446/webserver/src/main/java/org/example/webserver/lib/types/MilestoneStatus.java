package org.example.webserver.lib.types;

public enum MilestoneStatus { IN_PROGRESS, COMPLETED, AT_RISK, }
