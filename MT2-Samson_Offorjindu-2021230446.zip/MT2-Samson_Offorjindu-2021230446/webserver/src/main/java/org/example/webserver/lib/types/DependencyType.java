package org.example.webserver.lib.types;

public enum DependencyType {
    FINISH_START,
    FINISH_FINISH,
    START_START,
    START_FINISH,
}