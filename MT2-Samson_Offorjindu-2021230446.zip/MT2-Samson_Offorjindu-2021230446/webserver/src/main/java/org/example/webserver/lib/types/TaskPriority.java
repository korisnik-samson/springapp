package org.example.webserver.lib.types;

public enum TaskPriority {
    LOW, MEDIUM, HIGH, URGENT
}
