package org.example.webserver.lib.types;

public enum UserRole {
     MANAGER, MEMBER
}
