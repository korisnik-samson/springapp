package org.example.webserver.lib.types;

public enum TaskStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    BLOCKED
}
