package org.example.webserver.lib.types;

public enum DeadlineType {
    PROJECT_START,
    PROJECT_END,
    MAJOR,
}