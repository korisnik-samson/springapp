package org.example.webserver.lib.types;

public enum SubtaskStatus {
    IN_PROGRESS, COMPLETED, NOT_STARTED
}
