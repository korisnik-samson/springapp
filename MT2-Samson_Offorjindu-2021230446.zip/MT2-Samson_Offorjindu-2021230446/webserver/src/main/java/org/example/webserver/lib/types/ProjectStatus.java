package org.example.webserver.lib.types;

public enum ProjectStatus {
    IN_PROGRESS, ON_HOLD, COMPLETED
}
