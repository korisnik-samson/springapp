package org.example.webserver.lib.types;

public enum IsObjectDeleted {
    TRUE, FALSE
}
