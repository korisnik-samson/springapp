package org.example.webserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
